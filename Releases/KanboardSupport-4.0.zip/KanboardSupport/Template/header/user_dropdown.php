<li class="support-dropdown">
    <?= $this->url->link($this->helper->supportHelper->embedSVGIcon('ks-icon') . t('Configuration'), 'TechnicalSupportController', 'show', ['plugin' => 'KanboardSupport', ]) ?>
</li>
