<li class="support-dropdown">
    <?= $this->url->icon('question-circle', t('Technical Information'), 'TechnicalSupportController', 'show', ['plugin' => 'KanboardSupport', ]) ?>
</li>
